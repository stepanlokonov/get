import pandas as pd
from matplotlib import pyplot as plt
import numpy as np
import math
data=pd.read_csv('bubble.csv').to_numpy()
y=data[:,0]
y=y/1000000
x=np.array([100, 1000, 10000, 20000, 50000, 80000, 100000])



data1=pd.read_csv('vstavka.csv').to_numpy()
y2=data1[:,0]
y2=y2/1000000




data2=pd.read_csv('vybor.csv').to_numpy()
y3=data2[:,0]
y3=y3/1000000





plt.xlabel('Длина массива, N')
plt.ylabel('Время сортировки, с')

line1, = plt.plot(x, y, 'blue')
line2, = plt.plot(x, y2, 'orange')
line3, = plt.plot(x, y3, 'green')
plt.legend((line1, line2, line3), ['Пузырьком', 'Вставкой', 'Выбором'])

plt.savefig('Пункт 0')
plt.show()

#Пузырьком
t=[]
n=[]
x=x.tolist()
y=y.tolist()
for i in range(len(x)):
    t.append(math.log(x[i], math.e))
t=np.array(t)
for i in range(len(y)):
    n.append(math.log(y[i], math.e))
n=np.array(n)
plt.scatter(t,n)


#Вставкой
n1=[]
y2=y2.tolist()
for i in range(len(y2)):
    n1.append(math.log(y2[i], math.e))
n1=np.array(n1)
plt.scatter(t,n1)

#Выбором
n2=[]
y3=y3.tolist()
for i in range(len(y3)):
    n2.append(math.log(y3[i], math.e))
n2=np.array(n2)
plt.scatter(t,n2)

#Прямая пузырьком

k=(np.mean(t*n)-np.mean(t)*np.mean(n))/(np.mean(t**2)-(np.mean(t))**2)
b=np.mean(n)-np.mean(t)*(np.mean(t*n)-np.mean(t)*np.mean(n))/(np.mean(t**2)-(np.mean(t))**2)
n11=b+k*t
line4,=plt.plot(t,n11)
print(k)
#Прямая вставкой
k2=(np.mean(t*n1)-np.mean(t)*np.mean(n1))/(np.mean(t**2)-(np.mean(t))**2)
b2=np.mean(n1)-np.mean(t)*(np.mean(t*n1)-np.mean(t)*np.mean(n1))/(np.mean(t**2)-(np.mean(t))**2)
n22=b2+k2*t
line5,=plt.plot(t,n22)
print(k2)
#Прямая выбором
k3=(np.mean(t*n2)-np.mean(t)*np.mean(n2))/(np.mean(t**2)-(np.mean(t))**2)
b3=np.mean(n2)-np.mean(t)*(np.mean(t*n2)-np.mean(t)*np.mean(n2))/(np.mean(t**2)-(np.mean(t))**2)
n33=b3+k3*t
line6,=plt.plot(t,n33)
print(k3)


plt.xlabel('ln(N)')
plt.ylabel('ln(t)')

line4, = plt.plot(t, n, 'blue')
line5, = plt.plot(t, n1, 'orange')
line6, = plt.plot(t, n2, 'green')
plt.legend((line4, line5, line6), ['Пузырьком, k=2,02', 'Вставкой, k=1.98', 'Выбором, k=2'])

plt.savefig('Пункт 0 прямая')

plt.show()









