#include <iostream>
using namespace std;
int main(){
    int n, a,b,i;
    cin >>n;
    a=0;
    b=1;
    i=2;
    if (n==1){
        cout<<0;
    }
    if (n==2){
        cout<<1;
    }
    if (n==3){
        cout<<1;
    }
    if (n>3){
        while(i!=n){
            b=b+a;
            a=b-a;
            i+=1;
        }
    }
    cout<<b;
    return 0;
}

