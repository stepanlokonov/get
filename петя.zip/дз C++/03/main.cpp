#include <fstream>
#include <iostream>
#include <chrono>
#include <random>
using namespace std;

double get_time() {
return std::chrono::duration_cast<std::chrono::microseconds>
(std::chrono::steady_clock::now().time_since_epoch()).count();
}

int rand_uns(int min, int max) {
    unsigned seed = std::chrono::steady_clock::now().time_since_epoch().count();
    static std::default_random_engine e(seed);
    std::uniform_int_distribution<int> d(min, max);
    return d(e);
}

const int z=100;
const int x=1000;
const int n=10000;
const int m=50000;
const int l=100000;
const int p=20000;
const int u=80000;


int main() {
    ofstream f("vybor.csv", ios::out);
    f << 0 << endl;
    int a[z], b[x], c[n], d[m], s[l], q[p], w[u];
    for(int i = 0; i < z; i++) {
        a[i] = rand_uns(1, 100);
    }

    for(int i = 0; i < x; i++) {
        b[i] = rand_uns(1, 1000);
    }

    for(int i = 0; i < n; i++) {
        c[i] = rand_uns(1, 10000);
    }

    for(int i = 0; i < m; i++) {
        d[i] = rand_uns(1, 100000);
    }
    for(int i = 0; i < l; i++) {
        s[i] = rand_uns(1, 100000);
    }
    for(int i = 0; i < p; i++) {
        q[i] = rand_uns(1, 100000);
    }
    for(int i = 0; i < u; i++) {
        w[i] = rand_uns(1, 100000);
    }




    double start = get_time();
    for (int i = 0; i < z - 1; i++)
        for (int j = i + 1; j < z; j++)
            if (a[j] < a[i])
                swap(a[i], a[j]);
    double end = get_time();
    double elapsed = end - start;
    f << elapsed << endl;


    double start1 = get_time();
    for (int i = 0; i < x - 1; i++)
        for (int j = i + 1; j < x; j++)
            if (b[j] < b[i])
                swap(b[i], b[j]);
    double end1 = get_time();
    double elapsed1 = end1 - start1;
    f << elapsed1 << endl;



    double start2 = get_time();
    for (int i = 0; i < n - 1; i++)
        for (int j = i + 1; j < n; j++)
            if (c[j] < c[i])
                swap(c[i], c[j]);
    double end2 = get_time();
    double elapsed2 = end2 - start2;
    f << elapsed2 << endl;


    double start5 = get_time();
    for (int i = 0; i < p - 1; i++)
        for (int j = i + 1; j < p; j++)
            if (q[j] < q[i])
                swap(q[i], q[j]);
    double end5 = get_time();
    double elapsed5 = end5 - start5;
    f << elapsed5 << endl;


    double start3 = get_time();
    for (int i = 0; i < m - 1; i++)
        for (int j = i + 1; j < m; j++)
            if (d[j] < d[i])
                swap(d[i], d[j]);
    double end3 = get_time();
    double elapsed3 = end3 - start3;
    f << elapsed3 << endl;


     double start6 = get_time();
    for (int i = 0; i < u - 1; i++)
        for (int j = i + 1; j < u; j++)
            if (w[j] < w[i])
                swap(w[i], w[j]);
    double end6 = get_time();
    double elapsed6 = end6 - start6;
    f << elapsed6 << endl;


    double start4 = get_time();
    for (int i = 0; i < l - 1; i++)
        for (int j = i + 1; j < l; j++)
            if (s[j] < s[i])
                swap(s[i], s[j]);
    double end4 = get_time();
    double elapsed4 = end4 - start4;
    f << elapsed4 << endl;










    return 0;

}
