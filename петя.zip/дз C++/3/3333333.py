import pandas as pd
from matplotlib import pyplot as plt
import numpy as np
data=pd.read_csv('bubble.csv').to_numpy()
y=data[:,0]
y=y/1000000
x=np.array([100, 1000, 10000, 20000, 50000, 80000, 100000])



data1=pd.read_csv('vstavka.csv').to_numpy()
y2=data1[:,0]
y2=y2/1000000




data2=pd.read_csv('vybor.csv').to_numpy()
y3=data2[:,0]
y3=y3/1000000


data3=pd.read_csv('shell.csv').to_numpy()
y4=data3[:,0]
y4=y4/1000000

data4=pd.read_csv('hoar.csv').to_numpy()
y5=data4[:,0]
y5=y5/1000000


data5=pd.read_csv('merge.csv').to_numpy()
y6=data5[:,0]
y6=y6/1000000


plt.xlabel('Длина массива, N')
plt.ylabel('Время сортировки, с')

line1, = plt.plot(x, y, 'blue')
line2, = plt.plot(x, y2, 'orange')
line3, = plt.plot(x, y3, 'green')
line4, = plt.plot(x, y4, 'red')
line5, = plt.plot(x, y5, 'black')
line6, = plt.plot(x, y6, 'pink')
plt.legend((line1, line2, line3, line4, line5, line6), ['Пузырьком', 'Вставкой', 'Выбором', 'Шелл', 'Хоар', 'Слияние'])

plt.savefig('Пункт 3')
plt.show()

