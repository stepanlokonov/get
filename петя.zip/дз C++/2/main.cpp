#include <fstream>
#include <iostream>
#include <chrono>
#include <random>
using namespace std;

double get_time() {
return std::chrono::duration_cast<std::chrono::microseconds>
(std::chrono::steady_clock::now().time_since_epoch()).count();
}

int rand_uns(int min, int max) {
    unsigned seed = std::chrono::steady_clock::now().time_since_epoch().count();
    static std::default_random_engine e(seed);
    std::uniform_int_distribution<int> d(min, max);
    return d(e);
}

const int z=100;
const int x=1000;
const int n=10000;
const int m=50000;
const int l=100000;
const int p=20000;
const int u=80000;

int main() {
    ofstream f("shell.csv", ios::out);
    f << 0 << endl;

    int a[z], b[x], c[n], d[m], s[l], q[p], w[u];
    for(int i = 0; i < z; i++) {
        a[i] = rand_uns(1, 10000);
    }

    for(int i = 0; i < x; i++) {
        b[i] = rand_uns(1, 100000);
    }

    for(int i = 0; i < n; i++) {
        c[i] = rand_uns(1, 100000);
    }

    for(int i = 0; i < m; i++) {
        d[i] = rand_uns(1, 1000000);
    }
    for(int i = 0; i < l; i++) {
        s[i] = rand_uns(1, 1000000);
    }
    for(int i = 0; i < p; i++) {
        q[i] = rand_uns(1, 1000000);
    }
    for(int i = 0; i < u; i++) {
        w[i] = rand_uns(1, 1000000);
    }


    double start = get_time();
    for (int gap = z / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < z; i++) {
            int temp = a[i];
            int j = i;

            while (j >= gap && a[j - gap] > temp) {
                a[j] = a[j - gap];
                j -= gap;
            }

            a[j] = temp;
        }
    }
    double end = get_time();
    double elapsed = end - start;
    f << elapsed << endl;



    double start2 = get_time();
    for (int gap = x / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < x; i++) {
            int temp = b[i];
            int j = i;

            while (j >= gap && b[j - gap] > temp) {
                b[j] = b[j - gap];
                j -= gap;
            }

            b[j] = temp;
        }
    }
    double end2 = get_time();
    double elapsed2 = end2 - start2;
    f << elapsed2 << endl;



    double start3 = get_time();
    for (int gap = n / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < n; i++) {
            int temp = c[i];
            int j = i;

            while (j >= gap && c[j - gap] > temp) {
                c[j] = c[j - gap];
                j -= gap;
            }

            c[j] = temp;
        }
    }
    double end3 = get_time();
    double elapsed3 = end3 - start3;
    f << elapsed3 << endl;



    double start6 = get_time();
    for (int gap = p / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < p; i++) {
            int temp = q[i];
            int j = i;

            while (j >= gap && q[j - gap] > temp) {
                q[j] = q[j - gap];
                j -= gap;
            }

            q[j] = temp;
        }
    }
    double end6 = get_time();
    double elapsed6 = end6 - start6;
    f << elapsed6 << endl;



    double start4 = get_time();
    for (int gap = m / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < m; i++) {
            int temp = d[i];
            int j = i;

            while (j >= gap && d[j - gap] > temp) {
                d[j] = d[j - gap];
                j -= gap;
            }

            d[j] = temp;
        }
    }
    double end4 = get_time();
    double elapsed4 = end4 - start4;
    f << elapsed4 << endl;




    double start7 = get_time();
    for (int gap = u / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < u; i++) {
            int temp = w[i];
            int j = i;

            while (j >= gap && w[j - gap] > temp) {
                w[j] = w[j - gap];
                j -= gap;
            }

            w[j] = temp;
        }
    }
    double end7 = get_time();
    double elapsed7 = end7 - start7;
    f << elapsed7 << endl;




    double start5 = get_time();
    for (int gap = l / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < l; i++) {
            int temp = s[i];
            int j = i;

            while (j >= gap && s[j - gap] > temp) {
                s[j] = s[j - gap];
                j -= gap;
            }

            s[j] = temp;
        }
    }
    double end5 = get_time();
    double elapsed5 = end5 - start5;
    f << elapsed5 << endl;


    return 0;
}
