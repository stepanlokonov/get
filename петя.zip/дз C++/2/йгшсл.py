import pandas as pd
from matplotlib import pyplot as plt
import numpy as np
import math
data=pd.read_csv('shell.csv').to_numpy()
y=data[:,0]
y=y/1000000
x=np.array([100, 1000, 10000, 20000, 50000, 80000, 100000])

data1=pd.read_csv('hoar.csv').to_numpy()
y1=data1[:,0]
y1=y1/1000000


data2=pd.read_csv('merge.csv').to_numpy()
y2=data2[:,0]
y2=y2/1000000


plt.xlabel('Длина массива, N')
plt.ylabel('Время сортировки, с')

line1, = plt.plot(x, y, 'blue')
line2, = plt.plot(x, y1, 'orange')
line3, = plt.plot(x, y2, 'green')
plt.legend((line1, line2, line3), ['Шелл', 'Хоар', 'Слияние'])

plt.savefig('Пункт 2')
plt.show()


x=x.tolist()
X=[]
for i in range(len(x)):
    X.append(math.log(x[i], 2))
X=np.array(X)
X=x*X
Y=y/X
Y1=y1/X
Y2=y2/X
line4, = plt.plot(x, Y, 'blue')
line5, = plt.plot(x, Y1, 'orange')
line6, = plt.plot(x, Y2, 'green')
plt.legend((line4, line5, line6), ['Шелл', 'Хоар', 'Слияние'])

plt.savefig('Пункт 2 ДОКАЗАТЕЛЬСТВО')
plt.show()



