#include <iostream>
#include <string>
using namespace std;
int main()
{
    string a,b;
    cin>>a;
    for(int i=0; i<a.length();i++){
        if(i%2==0){
            cout<<a[i];
        }
    }
    for(int i=0; i<a.length();i++){
        if(i%2==1){
            cout<<a[i];
        }
    }
    return 0;
}
