import pandas as pd
from matplotlib import pyplot as plt
import numpy as np
import math
data=pd.read_csv('bubbleO0.csv').to_numpy()
y=data[:,0]
y=y/1000000
x=np.array([100, 1000, 10000, 20000, 50000, 80000, 100000])



data1=pd.read_csv('bubbleO1.csv').to_numpy()
y2=data1[:,0]
y2=y2/1000000




data2=pd.read_csv('bubbleO2.csv').to_numpy()
y3=data2[:,0]
y3=y3/1000000

data3=pd.read_csv('bubbleO3.csv').to_numpy()
y4=data3[:,0]
y4=y4/1000000


plt.xlabel('Длина массива, N')
plt.ylabel('Время сортировки, с')

line1, = plt.plot(x, y, 'blue')
line2, = plt.plot(x, y2, 'orange')
line3, = plt.plot(x, y3, 'green')
line4,=plt.plot(x, y4, 'red')
plt.legend((line1, line2, line3, line4), ['O0', 'O1', 'O2', 'O3'])

plt.savefig('Пункт 1')
plt.show()
